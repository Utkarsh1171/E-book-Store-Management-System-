package com.example.excelupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceluploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
