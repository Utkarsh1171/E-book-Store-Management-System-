package com.example.excelupload.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@Service
public class ExcelService {

    // Method to process the uploaded Excel file
    public List<Map<String, Object>> processExcelFile(MultipartFile file) {
        List<Map<String, Object>> excelData = new ArrayList<>();

        try {
            // Create a Workbook from the uploaded file
            Workbook workbook = new XSSFWorkbook(file.getInputStream());

            Sheet sheet = workbook.getSheetAt(0);

            // Iterate through each row in the sheet
            for (Row row : sheet) {
                Map<String, Object> rowData = new HashMap<>();

                for (Cell cell : row) {
                    String key = "Column-" + cell.getColumnIndex();
                    Object value = getCellValue(cell);

                    // Print the value to the console
                    System.out.println("Cell Value at [" + row.getRowNum() + "," + cell.getColumnIndex() + "]: " + value);

                    rowData.put(key, value);
                }

                excelData.add(rowData);
            }

            workbook.close();

        } catch (IOException e) {

            throw new RuntimeException("Failed to process Excel file: " + e.getMessage(), e);
        }
        return excelData;
    }

    private Object getCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue();
                } else {
                    return cell.getNumericCellValue();
                }
            case BOOLEAN:
                return cell.getBooleanCellValue();
            default:
                return cell.toString();
        }
    }
}
